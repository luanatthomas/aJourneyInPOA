import SwiftUI

struct PortoAlegreView: View {
    var body: some View {
        GeometryReader { reader in
            ZStack{
                Color(red: 16 / 255, green: 43 / 255, blue: 22 / 255)
                
                HStack{
                    Spacer()
                    Image("map")
                        .resizable()
                        .scaledToFill()
                        .frame(width: reader.size.width * 0.8, height: reader.size.height, alignment: .leading )
                        .clipped()
                }
                .padding(.vertical, -25)
                
                VStack{
                    Spacer()
                    HStack (alignment: .bottom){
                        Image("lu")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: reader.size.height * 0.3)
                            .padding(.horizontal, 60)
                        
                        Spacer()
                        NavigationLink {
                            CreditsView()
                        } label: {
                            Image("finish")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: reader.size.width * 0.08)
                                .padding(.bottom, reader.size.height * 0.05)
                        }
                        .buttonStyle(.plain)
                        .padding(.horizontal, 60)
                    }
                }
                
                VStack (alignment: .center) {
                    Image("title")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: reader.size.height * 0.05)
                        .padding(.vertical, reader.size.height * 0.04)
                    
                    
                    Spacer()
                }
                
                
                HStack (spacing: reader.size.width * 0.1){
                    VStack{
                        Text("Click on the images to discover the city with Lu!")
                            .font(.custom("SF Pro Rounded", size: reader.size.height*0.025))
                            .fontWeight(.regular)
                            .multilineTextAlignment(.center)
                            .lineSpacing(18)
                            .foregroundColor(.white)
                        //.padding(.horizontal, reader.size.width * 0.05)
                        //.frame(width: reader.size.width * 0.2)
                    }.frame(width: reader.size.width * 0.2)
                    
                    
                    //Spacer()
                    
                    VStack (spacing: reader.size.height * 0.05){
                        HStack {
                            NavigationLink{
                                MarioQuintanaView()
                            } label: {
                                VStack(alignment: .center, spacing: 10){
                                    Image("marioQuintana")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: reader.size.width * 0.15)
                                    VStack {
                                        Text("Casa de cultura Mário Quintana")
                                            .font(.custom("SF Pro Rounded", size: reader.size.height*0.02))
                                            .fontWeight(.bold)
                                            .multilineTextAlignment(.center)
                                            .foregroundColor(.white)
                                        
                                        Text("Mario Quintana House of Culture")
                                            .font(.custom("SF Pro Rounded", size: reader.size.height*0.015))
                                            .fontWeight(.light)
                                            .multilineTextAlignment(.center)
                                            .foregroundColor(.white)
                                    }
                                }
                                .frame(width: reader.size.width * 0.22, height: reader.size.height * 0.2)
                            }
                            .buttonStyle(.plain)
                            
                            NavigationLink{
                                OrlaGuaibaView()
                            } label: {
                                VStack(alignment: .center, spacing: 10){
                                    Image("orlaDoGuaiba")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: reader.size.width * 0.15)
                                    VStack {
                                        Text("Orla do Guaíba")
                                            .font(.custom("SF Pro Rounded", size: reader.size.height*0.02))
                                            .fontWeight(.bold)
                                            .multilineTextAlignment(.center)
                                            .foregroundColor(.white)
                                        
                                        Text("Guaiba Bay")
                                            .font(.custom("SF Pro Rounded", size: reader.size.height*0.015))
                                            .fontWeight(.light)
                                            .multilineTextAlignment(.center)
                                            .foregroundColor(.white)
                                    }
                                }
                                .frame(width: reader.size.width * 0.22, height: reader.size.height * 0.2)
                            }
                            .buttonStyle(.plain)
                        }
                        
                        
                        HStack{
                            NavigationLink{
                                JardimBotanicoView()
                            } label: {
                                VStack(alignment: .center, spacing: 10){
                                    Image("jardimBotanico")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: reader.size.width * 0.15)
                                    VStack {
                                        Text("Jardim Botânico")
                                            .font(.custom("SF Pro Rounded", size: reader.size.height*0.02))
                                            .fontWeight(.bold)
                                            .multilineTextAlignment(.center)
                                            .foregroundColor(.white)
                                        
                                        Text("Botanical Garden")
                                            .font(.custom("SF Pro Rounded", size: reader.size.height*0.015))
                                            .fontWeight(.light)
                                            .multilineTextAlignment(.center)
                                            .foregroundColor(.white)
                                    }
                                }
                                .frame(width: reader.size.width * 0.22, height: reader.size.height * 0.2)
                                
                            }
                            .buttonStyle(.plain)
                            
                            NavigationLink{
                                RedencaoView()
                            } label: {
                                VStack(alignment: .center, spacing: 10){
                                    Image("redencao")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: reader.size.width * 0.15)
                                    VStack {
                                        Text("Parque Farroupilha")
                                            .font(.custom("SF Pro Rounded", size: reader.size.height*0.02))
                                            .fontWeight(.bold)
                                            .multilineTextAlignment(.center)
                                            .foregroundColor(.white)
                                        
                                        Text("Farroupilha Park")
                                            .font(.custom("SF Pro Rounded", size: reader.size.height*0.015))
                                            .fontWeight(.light)
                                            .multilineTextAlignment(.center)
                                            .foregroundColor(.white)
                                    }
                                }
                                .frame(width: reader.size.width * 0.22, height: reader.size.height * 0.2)
                                
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                .padding(.horizontal, reader.size.width * 0.05)
            }
        }
        .navigationBarHidden(true)
    }
}
