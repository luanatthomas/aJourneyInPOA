import SwiftUI

struct RedencaoView: View {
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        GeometryReader { reader in
            ZStack{
                Color(red: 16 / 255, green: 43 / 255, blue: 22 / 255)
                
                VStack {
                    HStack {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss()
                        }) {
                            Image("arrow")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(height: reader.size.height * 0.05)
                                .padding(.top, reader.size.height * 0.055)
                                .padding(.horizontal, reader.size.width * 0.05)
                        }
                        Spacer()
                    }
                    Spacer()
                }
                
                VStack (alignment: .center, spacing: reader.size.height * 0.05){
                    HStack (alignment: .center){
                        Image("title")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: reader.size.height * 0.05)
                            .padding()
                    }
                    
                    HStack (alignment: .top) {
                        VStack (spacing: reader.size.height * 0.05){
                            VStack (spacing: reader.size.height * 0.01){
                                Text("Parque Farroupilha")
                                    .font(.custom("SF Pro Rounded", size: reader.size.height*0.03))
                                    .fontWeight(.bold)
                                    .multilineTextAlignment(.center)
                                    .lineSpacing(18)
                                    .padding(.horizontal)
                                    .foregroundColor(.white)
                                
                                Text("Farroupilha Park")
                                    .font(.custom("SF Pro Rounded", size: reader.size.height*0.02))
                                    .fontWeight(.light)
                                    .multilineTextAlignment(.center)
                                    .lineSpacing(18)
                                    .padding(.horizontal)
                                    .foregroundColor(.white)
                            }
                            .padding(.top)
                            
                            Text("Parque Farroupilha is one of the main postcards of the city. Lu loves to visit the park to ride a bike and practice outdoor activities. In addition, on Saturdays, there is always the popular Redenção Fair and it is a great place to walk with friends and drink the famous chimarrão, a traditional drink from southern Brazil made from mate tea and hot water.")
                                .font(.custom("SF Pro Rounded", size: reader.size.height*0.025))                                
                                .fontWeight(.regular)
                                .multilineTextAlignment(.center)
                                .lineSpacing(18)
                                .padding(.horizontal, reader.size.width * 0.05)
                                .foregroundColor(.white)
                        }
                        .frame(width: reader.size.width * 0.6)
                        .padding(.top, reader.size.height * 0.03)
                        
                        VStack (spacing: reader.size.height * 0.04) {
                            Image("redencao1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .padding()
                            Image("redencao2")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .padding()
                            Spacer()
                        }
                        .frame(width: reader.size.width * 0.3)
                        .padding(.top, reader.size.height * 0.07)
                    }
                    .frame(height: reader.size.height * 0.8)
                }    
                .padding()
            }
        }
        .navigationBarHidden(true)
    }
}
