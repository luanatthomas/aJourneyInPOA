import SwiftUI

struct HomeView1: View {
    var body: some View {
        GeometryReader { reader in
                ZStack{
                    Color(red: 16 / 255, green: 43 / 255, blue: 22 / 255)
                    
                    HStack{
                        Image("flowers1")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: reader.size.width * 0.04, height: reader.size.height)
                            .clipped()
                        Spacer()
                        Image("flowers1")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: reader.size.width * 0.04, height: reader.size.height)
                            .clipped()
                    }
                    
                    VStack (alignment: .center){
                        Image("title")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: reader.size.height * 0.05)
                        
                        Spacer()
                        
                        HStack {
//                            Image("books1")
//                                .resizable()
//                                .aspectRatio(contentMode: .fit)
//                                .frame(width: reader.size.width * 0.1)
//                            
                           // Spacer()
                            
                            VStack (alignment: .center){
                                //Text("Have you ever imagined living alone in a new and completely different city from what you're used to? This is quite common among students, and a new city can be quite scary in the beginning!")
                                Text("Have you ever imagined living alone in a new and completely different city from what you're used to? This is quite common among young people who leave their parents' home to study, and a new city can be quite scary in the beginning!")
                                    .font(.custom("SF Pro Rounded", size: reader.size.height*0.03))
                                    .fontWeight(.regular)
                                    .multilineTextAlignment(.center)
                                    .lineSpacing(18)
                                    .foregroundColor(.white)
                            }
                            .padding(.horizontal, reader.size.width * 0.2)
                            
//                            Spacer()
//                            
//                            Image("questions")
//                                .resizable()
//                                .aspectRatio(contentMode: .fit)
//                                .frame(width: reader.size.width * 0.1)
                        }
                        
                        
                        
                        Spacer()
                        
                        NavigationLink {
                            HomeView2()
                        } label: {
                            Image("next")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(height: reader.size.height * 0.05)
                        }
                    }   
                    .padding(reader.size.width * 0.05)
                }
            
            }
        .navigationBarHidden(true)
    }
}
