import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            GeometryReader { reader in
                ZStack{
                    Color(red: 16 / 255, green: 43 / 255, blue: 22 / 255)
                    VStack (alignment: .center, spacing: reader.size.height * 0.1) {

                        Image("logo")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: reader.size.width * 0.4)
                        
                        VStack (alignment: .center, spacing: reader.size.height * 0.05){
                            Image("subtitle")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(height: reader.size.height * 0.05)
                            
                            NavigationLink {
                                HomeView1()
                            } label: {
                                Image("letsgo")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(height: reader.size.height * 0.05)
                            }
                       }
                    }
                    .padding()
                }
            }
        }
        .navigationBarHidden(true)
    }    
}

