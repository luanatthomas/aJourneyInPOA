import SwiftUI

struct CreditsView: View {
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        GeometryReader { reader in
            ZStack{
                Color(red: 16 / 255, green: 43 / 255, blue: 22 / 255)
                
                HStack{
                    Image("flowers1")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: reader.size.width * 0.04, height: reader.size.height)
                        .clipped()
                    Spacer()
                    Image("flowers1")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: reader.size.width * 0.04, height: reader.size.height)
                        .clipped()
                }
                
                VStack (alignment: .center){
                    Image("title")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: reader.size.height * 0.05)
                    
                    Spacer()
                    
                    HStack {
                        VStack (alignment: .center){
                            Text("I hope you enjoyed getting to know a bit of Porto Alegre with Lu! It was super fun developing this app and trying to convey a bit of the experience of living in a completely new place through the photos and illustrations I created myself! If you want to relive your journey through Porto Alegre, click the button below and come on an adventure again!")
                                .font(.custom("SF Pro Rounded", size: reader.size.height*0.03))
                                .fontWeight(.regular)
                                .multilineTextAlignment(.center)
                                .lineSpacing(18)
                                .foregroundColor(.white)
                        }
                        .padding(.horizontal, reader.size.width * 0.2)
                    }
                    
                    Spacer()
                    
                    NavigationLink {
                        ContentView()
                    } label: {
                        Image("restart")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: reader.size.height * 0.05)
                    }
                }   
                .padding(reader.size.width * 0.05)
            }
            
        }
        .navigationBarHidden(true)
    }
}
