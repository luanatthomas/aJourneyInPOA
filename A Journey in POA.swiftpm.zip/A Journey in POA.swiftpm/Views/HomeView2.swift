import SwiftUI

struct HomeView2: View {
    var body: some View {
        GeometryReader { reader in
            ZStack{
                Color(red: 16 / 255, green: 43 / 255, blue: 22 / 255)
                
                HStack{
                    Image("flowers1")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: reader.size.width * 0.04, height: reader.size.height)
                        .clipped()
                    Spacer()
                    Image("flowers1")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: reader.size.width * 0.04, height: reader.size.height)
                        .clipped()
                }
                
                VStack (alignment: .center){
                    Image("title")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: reader.size.height * 0.05)
                    
                    Spacer()
                    
                    Image("thisislu")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: reader.size.height * 0.15)
                    
                    Spacer()
                    
                    Text("Lu lived in the countryside of the state of Rio Grande do Sul - Brazil and her biggest dream was to attend a Technology College. For that, she had to move to the capital city of Porto Alegre (POA), and her biggest challenge is getting to know the city on her own. \n\nCome and discover the city with her!")
                        .font(.custom("SF Pro Rounded", size: reader.size.height*0.025))
                        .fontWeight(.regular)
                        .multilineTextAlignment(.center)
                        .lineSpacing(18)
                        .padding(.horizontal, reader.size.width * 0.2)
                        .foregroundColor(.white)
                    Spacer()
                    
                    
                    NavigationLink {
                        PortoAlegreView()
                    } label: {
                        Image("start")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: reader.size.height * 0.05)
                    }
                    
                } 
                .padding(reader.size.width * 0.05)
            }
        }
        .navigationBarHidden(true)
    }
}
